import json
import requests
import urllib


from main import *

dict = {}

api_key= 'g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy'
class IPQS:


    def malicious_url_scanner_api(self, url: str, vars: dict = {}) -> dict:
        url = 'https://www.ipqualityscore.com/api/json/url/%s/%s'%(api_key, urllib.parse.quote_plus(url))


        x = requests.get(url, params=vars)
        print(x.text)
        return (json.loads(x.text))





def check(url, api_key):
    ipqs = IPQS()
    api_key="g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy"
    result = ipqs.malicious_url_scanner_api(url, {})
    res = result

    if 'success' in res and res['success'] == True:
        res = {k: res[k] for k in ['domain', 'suspicious', 'ip_address', 'malware', 'phishing'] if k in res}

    return res


