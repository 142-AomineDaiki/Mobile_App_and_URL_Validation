'''


import json
import requests
import urllib

from bro import *
from flask import request
from flask import Flask
from flask import render_template
app = Flask(__name__)

dict ={}

key = 'g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy'

@app.route('/', methods=['GET', 'POST'])

def search():
    if request.method == 'POST':
        dict = {}

        key = 'g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy'

        input_text = request.form.get('input_text')

        "processed_output = IPQS.malicious_url_scanner_api(key,input_text,dict)"


        processed_output = check(input_text,key)

        return render_template('index.html', processed_output=processed_output, input_text=input_text)

    return render_template('index.html')


'''



'''
@app.route('/', methods=['GET', 'POST'])
def process_input():

    if request.method == 'POST':

        input_text = request.form.get('input_text')

        processed_output = process_text(input_text)

        #return json.dumps(processed_output)
        return render_template('main.html',processed_output = processed_output, input_text = input_text)

'''




'''

if __name__ == "__main__":
    app.run(debug=True)

'''




'''



from flask import request, Flask, render_template
from bro import check

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        api_key = 'g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy'
        input_text = request.form.get('input_text')
        processed_output = check(input_text, api_key)
        return render_template('index.html', processed_output=processed_output, input_text=input_text)
    return render_template('index.html')

if __name__ == "_main_":
    app.run(debug=True)
    
    
    
    
 '''







import json
import requests
import urllib

from bro import *
from flask import request
from flask import Flask
from flask import render_template
app = Flask(__name__)

dict ={}

key = 'g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy'

@app.route('/', methods=['GET', 'POST'])

def search():
    if request.method == 'POST':
        api_key = 'g0nr2TzIDrcXeHAvUggmKLmzbzV6Omwy'
        input_text = request.form.get('input_text')
        processed_output = check(input_text, api_key)

        print(processed_output)


        "processed_output = IPQS.malicious_url_scanner_api(key,input_text,dict)"




        return render_template('index.html', processed_output=processed_output, input_text=input_text)

    return render_template('a.html')


if __name__ == "__main__":
    app.run(debug=True)